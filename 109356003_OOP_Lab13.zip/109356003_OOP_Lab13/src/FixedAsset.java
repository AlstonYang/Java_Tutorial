
public interface FixedAsset {

	void calcDepreciationExp();
	void calcBookValue();
	double getDepreciationExp();
	double getBookValue();
}
